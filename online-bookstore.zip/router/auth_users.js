const express = require('express');
const jwt = require('jsonwebtoken');
let books = require("./booksdb.js");
const reg_users = express.Router();

let users = [];

const authenticatedUser = (username, password) => {
    return users.some(u => u.username === username && u.password === password);
}

// Task 7: Login User
reg_users.post("/login", (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    if (!username || !password) {
        return res.status(404).json({ message: "Error logging in" });
    }
    if (authenticatedUser(username, password)) {
        let accessToken = jwt.sign({ data: password }, 'access', { expiresIn: 60 * 60 });
        req.session.authorization = { accessToken, username };
        return res.status(200).send("User successfully logged in");
    } else {
        return res.status(281).json({ message: "Invalid Login. Check username and password" });
    }
});

// Task 8: Add/Modify a book review
reg_users.put("/auth/review/:isbn", (req, res) => {
    const isbn = req.params.isbn;
    const review = req.query.review;
    const username = req.session.authorization.username;
    if (books[isbn]) {
        books[isbn].reviews[username] = review;
        return res.status(200).json({ message: "Review successfully added/modified", reviews: books[isbn].reviews });
    }
    return res.status(404).json({ message: "Book not found" });
});

// Task 9: Delete a book review
reg_users.delete("/auth/review/:isbn", (req, res) => {
    const isbn = req.params.isbn;
    const username = req.session.authorization.username;
    if (books[isbn]) {
        if (books[isbn].reviews[username]) {
            delete books[isbn].reviews[username];
            return res.status(200).json({ message: "Review deleted successfully" });
        }
        return res.status(404).json({ message: "No review found for this user" });
    }
    return res.status(404).json({ message: "Book not found" });
});

module.exports.authenticated = reg_users;
module.exports.isValid = (username) => users.some(u => u.username === username);
module.exports.users = users;
