const express = require('express');
let books = require("./booksdb.js");
let isValid = require("./auth_users.js").isValid;
let users = require("./auth_users.js").users;
const public_users = express.Router();

// Task 6: Register User
public_users.post("/register", (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    if (username && password) {
        if (!users.some(u => u.username === username)) {
            users.push({ "username": username, "password": password });
            return res.status(200).json({ message: "User successfully registered. Now you can login" });
        } else {
            return res.status(404).json({ message: "User already exists!" });
        }
    }
    return res.status(404).json({ message: "Unable to register user." });
});

// Task 1 & 10: Get all books (Using Async/Await)
public_users.get('/', async function (req, res) {
    try {
        return res.status(200).send(JSON.stringify(books, null, 4));
    } catch (error) {
        return res.status(500).json({ message: "Error fetching books" });
    }
});

// Task 2 & 10: Get book details based on ISBN (Using Promises)
public_users.get('/isbn/:isbn', function (req, res) {
    const isbn = req.params.isbn;
    new Promise((resolve, reject) => {
        if (books[isbn]) resolve(books[isbn]);
        else reject("Book not found");
    })
    .then((book) => res.status(200).send(JSON.stringify(book, null, 4)))
    .catch((err) => res.status(404).json({ message: err }));
});

// Task 3 & 10: Get book details based on Author
public_users.get('/author/:author', function (req, res) {
    const author = req.params.author;
    new Promise((resolve) => {
        let results = Object.values(books).filter(b => b.author === author);
        resolve(results);
    })
    .then((bookList) => res.status(200).send(JSON.stringify(bookList, null, 4)));
});

// Task 4 & 10: Get book details based on Title
public_users.get('/title/:title', function (req, res) {
    const title = req.params.title;
    new Promise((resolve) => {
        let results = Object.values(books).filter(b => b.title === title);
        resolve(results);
    })
    .then((bookList) => res.status(200).send(JSON.stringify(bookList, null, 4)));
});

// Task 5: Get book review
public_users.get('/review/:isbn', function (req, res) {
    const isbn = req.params.isbn;
    if (books[isbn]) {
        return res.status(200).send(JSON.stringify(books[isbn].reviews, null, 4));
    }
    return res.status(404).json({ message: "Book not found" });
});

module.exports.general = public_users;
